For using the effects, just drag and drop prefab on
scene. 

Ratings and reviews are much appreciated!

If you have questions or suggestions,
send them to my email: Glowinghuman@gmail.com